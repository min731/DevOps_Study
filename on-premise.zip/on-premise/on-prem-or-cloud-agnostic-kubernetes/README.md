# on-prem-or-cloud-agnostic-kubernetes
Setting up and running an on-prem or cloud agnostic Kubernetes cluster

This is the course material for the On-Prem or Cloud Agnostic Udemy Course on Udemy (see https://www.udemy.com/learn-devops-on-prem-or-cloud-agnostic-kubernetes/?couponCode=KUBERNETES_GIT)

# 메모
kubeadm
1. deb / rpm 패키지 호환
2. token을 통해 여러 노드들을 join
3. CNI은 직접 설치해야함 (ex calico)